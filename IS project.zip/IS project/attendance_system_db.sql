-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2023 at 09:44 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendance_system_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance_records`
--

CREATE TABLE `attendance_records` (
  `id` bigint(20) NOT NULL,
  `lecturer_id` varchar(100) NOT NULL,
  `scanned_data` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance_records`
--

INSERT INTO `attendance_records` (`id`, `lecturer_id`, `scanned_data`) VALUES
(6, 'lec-001', 'IS+project+2023');

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_type` varchar(100) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`id`, `user_id`, `user_type`, `user_name`, `password`, `date`) VALUES
(3, 591370858584, 'admin', 'adm-001', '$2y$10$OJGgGLtk2m1qkAh61gw5V.UF5hE/UK2auyRLdvHkKc6I9EQK/ljgi', '2023-11-20 07:56:58');

-- --------------------------------------------------------

--
-- Table structure for table `tblattendance`
--

CREATE TABLE `tblattendance` (
  `id` bigint(20) NOT NULL,
  `registration_no` varchar(100) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `course_level` varchar(200) NOT NULL,
  `status` varchar(20) NOT NULL,
  `dateTaken` varchar(20) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblattendance`
--

INSERT INTO `tblattendance` (`id`, `registration_no`, `course_name`, `course_level`, `status`, `dateTaken`, `date`) VALUES
(1, 'std-001', 'business management', 'diploma', '1', '2023-11-26', '2023-11-26 16:03:43'),
(2, 'std-001', 'business management', 'diploma', '1', '2023-11-27', '2023-11-27 10:28:45'),
(3, 'std-002', 'law', 'diploma', '0', '2023-11-27', '2023-11-27 14:57:45'),
(4, 'std-005', 'law', 'diploma', '0', '2023-11-27', '2023-11-27 14:57:45'),
(5, 'std-007', 'bcom', 'diploma', '1', '2023-11-27', '2023-11-27 17:24:16'),
(6, 'std-001', 'business management', 'diploma', '0', '2023-12-04', '2023-12-04 06:12:17'),
(7, 'std-004', 'business management', 'diploma', '0', '2023-12-04', '2023-12-04 06:12:17');

-- --------------------------------------------------------

--
-- Table structure for table `tbllecture`
--

CREATE TABLE `tbllecture` (
  `id` bigint(20) NOT NULL,
  `course_code` varchar(100) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbllecture`
--

INSERT INTO `tbllecture` (`id`, `course_code`, `course_name`, `date`) VALUES
(1, 'dbm001', 'business management', '2023-11-26 15:50:48'),
(2, 'llb001', 'law', '2023-11-26 15:51:09'),
(3, 'ds001', 'data science', '2023-11-27 14:35:03'),
(4, 'bcom001', 'bcom', '2023-11-27 17:18:47'),
(5, 'cs-001', 'computer science', '2023-12-04 17:28:47');

-- --------------------------------------------------------

--
-- Table structure for table `tbllecturer`
--

CREATE TABLE `tbllecturer` (
  `id` bigint(20) NOT NULL,
  `user_type` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) NOT NULL,
  `staff_no` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(100) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `course_level` varchar(100) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbllecturer`
--

INSERT INTO `tbllecturer` (`id`, `user_type`, `first_name`, `last_name`, `middle_name`, `staff_no`, `email`, `phone_number`, `course_name`, `course_level`, `user_name`, `password`, `date`) VALUES
(1, 'lecturer', 'Steven', 'Ennis', 'Otieno', 'lec-001', 'steven@gmail.com', '0712345678', 'business management', 'diploma', 'lec-001', '$2y$10$c73gNqBQmezwOV8alKtXfOTeldQoignCrmJJSuvbEnZmssYoKd/B.', '2023-11-26 15:53:05'),
(2, 'lecturer', 'denzel', 'jones', 'ennis', 'lec-002', 'djones@gmail.com', '072456245326', 'law', 'diploma', 'lec-002', '$2y$10$46P7nXrW0Mrjj8v/rYwJHu.aAkmiSDDpC1b0MDd8Q5/s1gYv7iRV6', '2023-11-27 14:53:51'),
(3, 'lecturer', 'Ray', 'Wafula', 'Wanyama', 'lec-003', 'rwafula@gmail.com', '07264257352', 'bcom', 'diploma', 'lec-003', '$2y$10$1gBMARhxpuHd9hfSTfn0aOkt38HJuqv2Da1KXq9Oui4FIcWU12qEi', '2023-11-27 17:20:37'),
(4, 'lecturer', 'Irene', 'Ommes', 'Labdi', 'lec-004', 'labdi@gmail.com', '0725242332', 'computer science', 'diploma', 'lec-004', '$2y$10$kaei2UK2Uo.rrqD.sQFuKOmpIMCpbeO6QKpEkVrVPkkivVjFZmz1W', '2023-12-04 17:31:33');

-- --------------------------------------------------------

--
-- Table structure for table `tblstudent`
--

CREATE TABLE `tblstudent` (
  `id` bigint(20) NOT NULL,
  `user_type` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `course_level` varchar(100) NOT NULL,
  `registration_no` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblstudent`
--

INSERT INTO `tblstudent` (`id`, `user_type`, `first_name`, `last_name`, `middle_name`, `course_name`, `course_level`, `registration_no`, `password`, `date`) VALUES
(3, 'student', 'Denzel', 'Jones', 'Ennis', 'business management', 'diploma', 'std-001', '$2y$10$QMkvWfLE2xOTIL35/NDPfOvqq/9O1BEOpf546YDxaEGbgNYzG2RBS', '2023-11-26 15:51:53'),
(4, 'student', 'Allan', 'Keter', 'Kipchumba', 'law', 'diploma', 'std-002', '$2y$10$B/nRgbHuE6EOGS1XHkSNIuh1N.mRe1izIhLmtpQuPFftfEx3VZ5xu', '2023-11-27 14:41:46'),
(5, 'student', 'Faith', 'Wendy', 'Wambui', 'data science', 'diploma', 'std-003', '$2y$10$WwVlVH6LNbC8Y39wh9cJteY/HBjGp8ssO7zA8XxhJBkc7rHNu8D7m', '2023-11-27 14:42:29'),
(6, 'student', 'Francis', 'Barasa', 'Sea', 'business management', 'diploma', 'std-004', '$2y$10$di2RMqB/tjTMaCkYAwxH1evBErLV.1iemW.jgWNagRMW6VBhgy0p.', '2023-11-27 14:48:11'),
(7, 'student', 'Jane ', 'Doe', 'Were', 'law', 'diploma', 'std-005', '$2y$10$8owqHBdt2caMrAAgUzoSV.Uy/G1.n3oEXh5iAXy2oOLiIhnFudfZa', '2023-11-27 14:49:23'),
(8, 'student', 'Austine', 'Odera', 'Otieno', 'data science', 'diploma', 'std-006', '$2y$10$P6vnvRr3v.01G7yrG1zaLuI5pdEYYllKOzxTaF0TnYiYQz3EAq8iy', '2023-11-27 14:50:00'),
(9, 'student', 'Nigel', 'Ciqala', 'Ennis', 'bcom', 'diploma', 'std-007', '$2y$10$J/FRVqUgi1JfKcsEf0PkveAHZBUMlxMpR9xaK6nc/4HUJlYh4sQQe', '2023-11-27 17:19:35'),
(10, 'student', 'Francis', 'Mbugua', 'Kamau', 'computer science', 'diploma', 'std-008', '$2y$10$ZO5sJLR3KdB4WhhsDW9VieRd/iMcJCMDQwZSxx704DxzFRvZSjelK', '2023-12-04 17:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_id`, `user_name`, `password`, `date`) VALUES
(1, 4929246904, 'denzel', '1234', '2023-10-22 17:40:12'),
(2, 81126679509, 'gacheru', '1234', '2023-10-23 15:30:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance_records`
--
ALTER TABLE `attendance_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lecturer_id` (`lecturer_id`),
  ADD KEY `scanned_data` (`scanned_data`);

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `user_type` (`user_type`),
  ADD KEY `user_name` (`user_name`);

--
-- Indexes for table `tblattendance`
--
ALTER TABLE `tblattendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `registration_no` (`registration_no`),
  ADD KEY `course_name` (`course_name`),
  ADD KEY `course_level` (`course_level`),
  ADD KEY `status` (`status`),
  ADD KEY `dateTaken` (`dateTaken`);

--
-- Indexes for table `tbllecture`
--
ALTER TABLE `tbllecture`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_code` (`course_code`),
  ADD KEY `course_name` (`course_name`);

--
-- Indexes for table `tbllecturer`
--
ALTER TABLE `tbllecturer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_type` (`user_type`),
  ADD KEY `user_name` (`user_name`),
  ADD KEY `first_name` (`first_name`),
  ADD KEY `last_name` (`last_name`),
  ADD KEY `middle_name` (`middle_name`),
  ADD KEY `staff_no` (`staff_no`),
  ADD KEY `email` (`email`),
  ADD KEY `phone_number` (`phone_number`),
  ADD KEY `course_name` (`course_name`),
  ADD KEY `course_level` (`course_level`);

--
-- Indexes for table `tblstudent`
--
ALTER TABLE `tblstudent`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_type` (`user_type`),
  ADD KEY `first_name` (`first_name`),
  ADD KEY `last_name` (`last_name`),
  ADD KEY `middle_name` (`middle_name`),
  ADD KEY `course_name` (`course_name`),
  ADD KEY `course_level` (`course_level`),
  ADD KEY `registration_no` (`registration_no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `user_name` (`user_name`),
  ADD KEY `password` (`password`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance_records`
--
ALTER TABLE `attendance_records`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblattendance`
--
ALTER TABLE `tblattendance`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbllecture`
--
ALTER TABLE `tbllecture`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbllecturer`
--
ALTER TABLE `tbllecturer`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblstudent`
--
ALTER TABLE `tblstudent`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
